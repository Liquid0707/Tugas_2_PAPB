package com.example.tugas2papd

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.Toast
import android.widget.EditText

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val loginButton: Button = findViewById(R.id.showHideBtn)
        loginButton.setOnClickListener(object : View.OnClickListener {
            override fun onClick(view: View) {
                Toast.makeText(applicationContext, "Login Berhasil", Toast.LENGTH_SHORT).show()
            }
        })
    }
}